import { MigrationInterface, QueryRunner } from "typeorm";

export class NewMigration1673502289995 implements MigrationInterface {
    name = 'NewMigration1673502289995'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "question_entity" ("id" SERIAL NOT NULL, "content" character varying NOT NULL, "titleId" integer, CONSTRAINT "PK_14a0a509f33d8cd3a96a448dcd7" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "title_entity" ("id" SERIAL NOT NULL, "name" character varying NOT NULL, CONSTRAINT "PK_1fd6877a433b88d1e5ff194cbba" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "supplier_entity" ("id" SERIAL NOT NULL, "name" character varying NOT NULL, "address" character varying NOT NULL, "phone" integer NOT NULL, CONSTRAINT "PK_72d4c59ef8e52fc761dfb5a20d9" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "chat_entity" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "email" character varying NOT NULL, "text" character varying NOT NULL, "createAt" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "UQ_e2fa1750b621339ea6249477009" UNIQUE ("text"), CONSTRAINT "PK_07e65670b36d025a69930ae6f2e" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "supplier_entity_title_title_entity" ("supplierEntityId" integer NOT NULL, "titleEntityId" integer NOT NULL, CONSTRAINT "PK_769d8b98b6dce8f5dede9d50c5e" PRIMARY KEY ("supplierEntityId", "titleEntityId"))`);
        await queryRunner.query(`CREATE INDEX "IDX_e91aa9a5e957b33baa404f1b87" ON "supplier_entity_title_title_entity" ("supplierEntityId") `);
        await queryRunner.query(`CREATE INDEX "IDX_7287db3e5798848d0692120063" ON "supplier_entity_title_title_entity" ("titleEntityId") `);
        await queryRunner.query(`ALTER TABLE "question_entity" ADD CONSTRAINT "FK_1b751740c4a61c42a442a58e501" FOREIGN KEY ("titleId") REFERENCES "title_entity"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "supplier_entity_title_title_entity" ADD CONSTRAINT "FK_e91aa9a5e957b33baa404f1b873" FOREIGN KEY ("supplierEntityId") REFERENCES "supplier_entity"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "supplier_entity_title_title_entity" ADD CONSTRAINT "FK_7287db3e5798848d0692120063c" FOREIGN KEY ("titleEntityId") REFERENCES "title_entity"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "supplier_entity_title_title_entity" DROP CONSTRAINT "FK_7287db3e5798848d0692120063c"`);
        await queryRunner.query(`ALTER TABLE "supplier_entity_title_title_entity" DROP CONSTRAINT "FK_e91aa9a5e957b33baa404f1b873"`);
        await queryRunner.query(`ALTER TABLE "question_entity" DROP CONSTRAINT "FK_1b751740c4a61c42a442a58e501"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_7287db3e5798848d0692120063"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_e91aa9a5e957b33baa404f1b87"`);
        await queryRunner.query(`DROP TABLE "supplier_entity_title_title_entity"`);
        await queryRunner.query(`DROP TABLE "chat_entity"`);
        await queryRunner.query(`DROP TABLE "supplier_entity"`);
        await queryRunner.query(`DROP TABLE "title_entity"`);
        await queryRunner.query(`DROP TABLE "question_entity"`);
    }

}
