import { TypeOrmModuleOptions } from "@nestjs/typeorm";
import 'dotenv/config';
import { DataSource, DataSourceOptions } from 'typeorm';
export const config: DataSourceOptions = {
    type: 'postgres',
    host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT),
    username: process.env.DB_USERNAME,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_DATABASE,
    // autoLoadEntities: true,
    // synchronize: true,
    entities: ['dist/src/**/*.entity.js'],
    migrationsRun: true,
    migrations: ['dist/**/migrations/*.{js,ts}'],

    // entities: [__dirname +'src/**/entity/*.entity{.ts,.js}'],
    // entities: [SupplierModule],
    // cli: {
    //     migrationsDir: 'dist/database/migrations' // migrate file sẽ được sinh ra tại đây
    // },
    // synchronize: true,  
    // cli: {
    //     migrationsDir: 'src/database/migrations' // migrate file sẽ được sinh ra tại đây
    //   }
    // entities: [__dirname +'./entity/*.entity{.ts,.js}'],
};

const data_Source = new DataSource(config)
export default data_Source;

