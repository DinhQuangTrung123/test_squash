import { TypeOrmModuleOptions } from "@nestjs/typeorm";
import 'dotenv/config'
import { DataSource, DataSourceOptions } from 'typeorm'

export const config: DataSourceOptions = {
    type: 'postgres',
    // host: process.env.DB_HOST,
    port: parseInt(process.env.DB_PORT),
    username: process.env.DB_USERNAME,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_DATABASE,
    migrations: [
        // 'dist/database/migrations/*.js',
        // 'database/migrations/*.ts'
    ],
    synchronize: true,  
    // cli: {
    //     migrationsDir: 'src/database/migrations' // migrate file sẽ được sinh ra tại đây
    //   },
    entities: [__dirname +'./entity/*.entity{.ts,.js}']
};  


const dataSource = new DataSource(config)
export default dataSource;

