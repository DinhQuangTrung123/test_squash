import { Document, Model, FilterQuery } from "mongoose";

export abstract class EntityRepository<T extends Document>{
    constructor(private readonly entityModel: Model<T>){}

    async addProduct( createEntityData: unknown):Promise<T>{
        const enity= new this.entityModel(createEntityData)
        return enity.save()
    }

    async getAllProducts(productEntityData: unknown):Promise<T[] | null>{
        const enity = new this.entityModel(productEntityData)
        return [enity]
    }
}