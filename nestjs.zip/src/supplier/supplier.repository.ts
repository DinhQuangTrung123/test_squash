// import { Injectable } from '@nestjs/common';
// import { InjectRepository } from '@nestjs/typeorm';
// import { EntityRepository } from 'database/entity.repository';
// import { Repository } from 'typeorm';
// import { SupplierEntity } from './entity/supplier.entity';


// @Injectable()
// export class SupplierService extends EntityRepository<SupplierEntity>{
//     constructor(@InjectRepository(SupplierEntity)
//     private supplisersRepository: Repository<SupplierEntity>
//     ){}
    
// }
