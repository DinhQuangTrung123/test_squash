import {
  IsString,
  IsNumber,
} from 'class-validator';

export class CreateTitleDTO {
    @IsString()
    name: string;
  }