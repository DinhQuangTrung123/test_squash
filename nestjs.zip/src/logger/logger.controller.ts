import { Controller } from '@nestjs/common';

@Controller('logger')
export class LoggerController {}
