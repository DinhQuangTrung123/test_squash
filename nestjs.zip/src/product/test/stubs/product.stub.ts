import { Product } from "src/product/schemas/product.schema";

//Product validate
// export const productstub = (): Product => {
export const productstub = (): Product => {
    return {
        id : '638088ee38f72866fddd6c67',
        name: 'product 8',
        description: 'ok ',
        price: 23,
        category: 'pant',
        urlimage:["software_architect_design-c3e20a34-dc4e-454b-9a0a-1ec2bf0d5e64.png"]
        // __v: 0
        // "_id": "638097be0321d0b3e6583c9e",
        // "name": "product 7",
        // "description": "perfect",
        // "price": 20,
        // "category": "pant",
        // "__v": 0
    }
}