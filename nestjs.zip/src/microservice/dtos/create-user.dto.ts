export class CreateOrderRequest {
    userId: string;
    price: number;
  }