export class CreateUserDTO {
    username: string;
    email: string;
    password: string;
    roles: string[];
  }