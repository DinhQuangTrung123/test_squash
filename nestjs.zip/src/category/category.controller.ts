import { Controller } from '@nestjs/common';

@Controller('category')
export class CategoryController {}
